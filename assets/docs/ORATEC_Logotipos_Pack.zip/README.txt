Pacote de logotipos ORATEC

Conteúdo:
- versões horizontal e quadrada
- cores azul, preto e branco
- arquivos PNG com fundo transparente
- versões originais com fundo branco
- favicons

Observação: estes arquivos foram preparados a partir dos logotipos aprovados nesta conversa.
